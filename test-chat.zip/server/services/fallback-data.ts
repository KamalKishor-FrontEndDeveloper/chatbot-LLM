import { HealthcareTreatment } from '@shared/schema';

// Fallback treatment data when API is unavailable
export const fallbackTreatments: HealthcareTreatment[] = [
  {
    id: 1,
    t_name: "Anti Wrinkle Injection (Botox)",
    name: "Anti Wrinkle Injection (Botox) (T)",
    price: "8000",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 2,
    t_name: "Dermal Fillers",
    name: "Dermal Fillers (T)",
    price: "15000",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 3,
    t_name: "HIFU (Face Lift)",
    name: "HIFU (Face Lift) (T)",
    price: "25000",
    doctors: "[1]",
    children: []
  },
  {
    id: 4,
    t_name: "Laser Hair Removal",
    name: "Laser Hair Removal (T)",
    price: "3000",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 5,
    t_name: "Hydrafacial MD",
    name: "Hydrafacial MD (T)",
    price: "4500",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 6,
    t_name: "Chemical Peel",
    name: "Chemical Peel (T)",
    price: "3500",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 7,
    t_name: "Microneedling",
    name: "Microneedling (T)",
    price: "4000",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 8,
    t_name: "Acne Treatment",
    name: "Acne Treatment (T)",
    price: "2500",
    doctors: "[1, 2]",
    children: []
  },
  {
    id: 9,
    t_name: "Hair Loss Treatment",
    name: "Hair Loss Treatment (T)",
    price: "5000",
    doctors: "[1]",
    children: []
  },
  {
    id: 10,
    t_name: "Pigmentation Treatment",
    name: "Pigmentation Treatment (T)",
    price: "4000",
    doctors: "[1, 2]",
    children: []
  }
];

export const fallbackDoctors = [
  {
    id: 1,
    name: "Dr. Niti Gaur",
    specialization: "Dermatologist",
    qualification: "MBBS, MD - Dermatology",
    experience: "20+ years",
    gender: "Female",
    phone: "9654122458",
    email: "info@citrineclinic.com",
    about: "Board-certified Dermatologist with expertise in clinical and cosmetic dermatology",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "Dermatology, Cosmetology, Trichology",
    is_available: true
  },
  {
    id: 2,
    name: "Dr. Medical Specialist",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Male",
    phone: "9654122458",
    email: "info@citrineclinic.com",
    about: "Experienced medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 11,
    name: "Dr DigiLantern",
    specialization: "Derma",
    qualification: "MS",
    experience: "5+ years",
    gender: "Male",
    phone: "8340615616",
    email: "demopms@digilantern.com",
    about: "Dermatology specialist",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "Dermatology",
    is_available: true
  },
  {
    id: 19068,
    name: "Dr. Karen Thomas",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Female",
    phone: "9654122458",
    email: "Karen@digilantern.com",
    about: "Experienced medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 19069,
    name: "Dr Sharmila Rathe",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Female",
    phone: "9654122458",
    email: "Sharmila@digilantern.com",
    about: "Experienced medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 19128,
    name: "Dr.Satish",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Male",
    phone: "9654122458",
    email: "satishkumar.digilantern@gmail.com",
    about: "Experienced medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 19129,
    name: "Dr. Kamal Kishor",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Male",
    phone: "9654122458",
    email: "kamal@gmail.com",
    about: "Experienced medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 19191,
    name: "Kartik",
    specialization: "General Practitioner",
    qualification: "MBBS",
    experience: "5+ years",
    gender: "Male",
    phone: "9654122458",
    email: "Kartik@gmail.com",
    about: "Medical practitioner",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "General Medicine",
    is_available: true
  },
  {
    id: 19543,
    name: "Prashant Mall",
    specialization: "Medical Specialist",
    qualification: "MBBS",
    experience: "10+ years",
    gender: "Male",
    phone: "9654122458",
    email: "prashantmall.digilantern@gmail.com",
    about: "Experienced medical specialist",
    image: "",
    address: "Citrine Clinic",
    city: "Delhi",
    state: "Delhi",
    services: "Medical Services",
    is_available: true
  }
];

export class FallbackDataService {
  getFallbackTreatments(): HealthcareTreatment[] {
    return fallbackTreatments;
  }

  searchFallbackTreatments(query: string): HealthcareTreatment[] {
    const searchTerms = query.toLowerCase().split(' ');
    return fallbackTreatments.filter(treatment => {
      const searchableText = `${treatment.t_name} ${treatment.name}`.toLowerCase();
      return searchTerms.some(term => searchableText.includes(term));
    });
  }

  getSpecificFallbackTreatment(query: string): HealthcareTreatment | null {
    const cleanQuery = query.toLowerCase()
      .replace(/\b(what|is|the|cost|of|price|for|in|treatment|therapy)\b/g, ' ')
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    // Treatment aliases for better matching
    const treatmentAliases: Record<string, string[]> = {
      'facelift': ['anti wrinkle injection', 'dermal filler', 'hifu', 'botox'],
      'botox': ['anti wrinkle injection', 'botulinum'],
      'hair removal': ['laser hair removal', 'lhr'],
      'acne': ['acne treatment', 'pimple treatment'],
      'hair loss': ['hair loss treatment', 'hair fall']
    };

    // Try exact match first
    let exactMatch = fallbackTreatments.find(treatment => {
      const treatmentName = treatment.t_name?.toLowerCase() || '';
      return treatmentName.includes(cleanQuery) || cleanQuery.includes(treatmentName);
    });

    // Try alias matching
    if (!exactMatch) {
      for (const [key, aliases] of Object.entries(treatmentAliases)) {
        if (cleanQuery.includes(key)) {
          exactMatch = fallbackTreatments.find(treatment => {
            const treatmentName = treatment.t_name?.toLowerCase() || '';
            return aliases.some(alias => treatmentName.includes(alias));
          });
          if (exactMatch) break;
        }
      }
    }

    return exactMatch || null;
  }

  getFallbackDoctors() {
    return fallbackDoctors;
  }

  getFallbackClinicInfo() {
    return {
      name: "Citrine Clinic",
      address: "Delhi, India",
      phone: "9654122458",
      email: "info@citrineclinic.com",
      working_hours: "Mon-Sat: 9 AM - 6 PM",
      services: [
        "Dermatology",
        "Cosmetology", 
        "Laser Treatments",
        "Anti-aging Treatments",
        "Hair Loss Treatment",
        "Acne Treatment"
      ]
    };
  }
}

export const fallbackDataService = new FallbackDataService();